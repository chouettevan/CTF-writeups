use std::io::{self, BufRead, Write};

pub const BUFFER_SIZE: usize = 144;
pub const MAX_LOGS: usize = 25;
pub const MAX_REFS: usize = 10;
const ANCHOR: &&() = &&();

fn cache_ref<'call, 'extended, T: ?Sized>(x: &'call mut T) -> &'extended mut T {
    fn coerce<'call, 'extended, T: ?Sized>(
        _: &'call &'extended (),
        v: &'extended mut T,
    ) -> &'call mut T {
        v
    }
    let f: fn(_, &'call mut T) -> &'extended mut T = coerce;
    f(ANCHOR, x)
}

fn alloc_ref() -> &'static mut [u8; BUFFER_SIZE] {
    let mut owned = Box::new([0u8; BUFFER_SIZE]);
    cache_ref(owned.as_mut())
}

fn banner(_ctx: *const u8) {}

fn win(_ctx: *const u8) {
    use std::io::Write;
    if let Ok(flag) = std::fs::read_to_string("/flag2") {
        let stdout = std::io::stdout();
        let mut h = stdout.lock();
        let _ = writeln!(h, "{}", flag.trim());
        let _ = h.flush();
    }
}

#[repr(C)]
pub struct AdminRecord {
    is_admin: u64,
    callback: Option<fn(*const u8)>,
    username: [u8; BUFFER_SIZE - (8 + 8)],
}

#[derive(Debug, PartialEq)]
pub enum Error {
    Full,
    OutOfRange,
    Deleted,
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Error::Full => write!(f, "Error: Storage is full"),
            Error::OutOfRange => write!(f, "Error: Index out of range"),
            Error::Deleted => write!(f, "Error: Entry was deleted"),
        }
    }
}

pub struct State {
    admins: Vec<Option<Box<AdminRecord>>>,
    logs: Vec<Option<Box<[u8; BUFFER_SIZE]>>>,
    refs: Vec<&'static mut [u8; BUFFER_SIZE]>,
}

impl State {
    pub fn new() -> Self {
        Self {
            admins: Vec::with_capacity(MAX_LOGS),
            logs: Vec::with_capacity(MAX_LOGS),
            refs: Vec::with_capacity(MAX_REFS),
        }
    }

    pub fn admin_new(&mut self) -> Result<usize, Error> {
        if self.admins.len() >= MAX_LOGS {
            return Err(Error::Full);
        }
        self.admins.push(Some(Box::new(AdminRecord {
            is_admin: 0,
            callback: Some(banner),
            username: [0u8; BUFFER_SIZE - 16],
        })));
        Ok(self.admins.len() - 1)
    }

    pub fn admin_show<W: Write>(&self, index: usize, w: &mut W) -> Result<(), Error> {
        match self.admins.get(index) {
            Some(Some(admin)) => {
                writeln!(w, "Is admin : {}", admin.is_admin).map_err(|_| Error::Deleted)?;
                w.flush().map_err(|_| Error::Deleted)?;

                if let Some(cb) = admin.callback {
                    cb(&**admin as *const AdminRecord as *const u8);
                }
                Ok(())
            }
            Some(None) => Err(Error::Deleted),
            None => Err(Error::OutOfRange),
        }
    }

    pub fn admin_drop(&mut self, index: usize) -> Result<(), Error> {
        match self.admins.get(index) {
            Some(Some(admin)) if admin.is_admin == 1 => {}
            Some(Some(_)) => return Err(Error::Deleted),
            Some(None) => return Err(Error::Deleted),
            None => return Err(Error::OutOfRange),
        }
        *self.admins.get_mut(index).unwrap() = None;
        Ok(())
    }

    pub fn admin_flag<W: Write>(&mut self, index: usize, w: &mut W) -> Result<(), Error> {
        match self.admins.get_mut(index) {
            Some(Some(admin)) => {
                if admin.is_admin == 1 {
                    let flag = std::env::var("FLAG1").expect("FLAG1 not set -- Contact organizers");
                    writeln!(w, "Congratulations! {}", flag).map_err(|_| Error::Deleted)?;
                    Ok(())
                } else {
                    Err(Error::Deleted)
                }
            }
            Some(None) => Err(Error::Deleted),
            None => Err(Error::OutOfRange),
        }
    }

    pub fn log_new(&mut self) -> Result<usize, Error> {
        if self.logs.len() >= MAX_LOGS {
            return Err(Error::Full);
        }
        #[allow(unused_mut)]
        let mut b = Box::new([0u8; BUFFER_SIZE]);
        self.logs.push(Some(b));
        Ok(self.logs.len() - 1)
    }

    pub fn log_show(&self, index: usize) -> Result<&[u8; BUFFER_SIZE], Error> {
        match self.logs.get(index) {
            Some(Some(b)) => Ok(b),
            Some(None) => Err(Error::Deleted),
            None => Err(Error::OutOfRange),
        }
    }

    pub fn log_edit(&mut self, index: usize, data: &[u8]) -> Result<(), Error> {
        match self.logs.get_mut(index) {
            Some(Some(b)) => {
                let n = data.len().min(BUFFER_SIZE);
                b[..n].copy_from_slice(&data[..n]);
                b[n..].fill(0);
                Ok(())
            }
            Some(None) => Err(Error::Deleted),
            None => Err(Error::OutOfRange),
        }
    }

    pub fn log_drop(&mut self, index: usize) -> Result<(), Error> {
        match self.logs.get_mut(index) {
            Some(slot @ Some(_)) => {
                *slot = None;
                Ok(())
            }
            Some(None) => Err(Error::Deleted),
            None => Err(Error::OutOfRange),
        }
    }

    pub fn ref_new(&mut self) -> Result<usize, Error> {
        if self.refs.len() >= MAX_REFS {
            return Err(Error::Full);
        }
        self.refs.push(alloc_ref());
        Ok(self.refs.len() - 1)
    }

    pub fn ref_show(&self, index: usize) -> Result<&[u8; BUFFER_SIZE], Error> {
        self.refs.get(index).map(|r| &**r).ok_or(Error::OutOfRange)
    }

    pub fn ref_edit(&mut self, index: usize, data: &[u8]) -> Result<(), Error> {
        match self.refs.get_mut(index) {
            Some(r) => {
                let n = data.len().min(BUFFER_SIZE);
                r[..n].copy_from_slice(&data[..n]);
                r[n..].fill(0);
                Ok(())
            }
            None => Err(Error::OutOfRange),
        }
    }
}

impl Default for State {
    fn default() -> Self {
        Self::new()
    }
}

fn read_line<R: BufRead>(r: &mut R) -> io::Result<String> {
    let mut line = String::new();
    r.read_line(&mut line)?;
    Ok(line.trim_end_matches(&['\n', '\r'][..]).to_owned())
}

fn prompt_index<R: BufRead, W: Write>(r: &mut R, w: &mut W) -> io::Result<usize> {
    write!(w, "Enter index: ")?;
    w.flush()?;
    Ok(read_line(r)?.trim().parse().unwrap_or(usize::MAX))
}

fn prompt_bytes<R: BufRead, W: Write>(r: &mut R, w: &mut W) -> io::Result<Vec<u8>> {
    write!(w, "Enter length: ")?;
    w.flush()?;
    let n: usize = read_line(r)?.trim().parse().unwrap_or(0);
    let n = n.clamp(1, BUFFER_SIZE);
    write!(w, "Enter {n} raw bytes: ")?;
    w.flush()?;
    let mut buf = vec![0u8; n];
    r.read_exact(&mut buf)?;
    let mut discard = String::new();
    r.read_line(&mut discard)?;
    Ok(buf)
}

fn hexdump<W: Write>(w: &mut W, data: &[u8]) -> io::Result<()> {
    for (row_index, row) in data.chunks(16).enumerate() {
        write!(w, "{:04x}: ", row_index * 16)?;
        for (i, byte) in row.iter().enumerate() {
            if i == 8 {
                write!(w, " ")?;
            }
            write!(w, "{:02x} ", byte)?;
        }
        let padding = 16 - row.len();
        for i in 0..padding {
            if row.len() + i == 8 {
                write!(w, " ")?;
            }
            write!(w, "   ")?;
        }
        write!(w, " |")?;
        for &byte in row {
            let c = if byte.is_ascii_graphic() || byte == b' ' {
                byte as char
            } else {
                '.'
            };
            write!(w, "{}", c)?;
        }
        writeln!(w, "|")?;
    }
    Ok(())
}

pub fn run<R: BufRead, W: Write>(r: &mut R, w: &mut W) -> io::Result<()> {
    let mut state = State::new();
    std::hint::black_box(win as fn(*const u8));

    writeln!(w, "[Claude G.P.T.]'s Activity Logger")?;
    writeln!(w)?;

    loop {
        writeln!(w, "1) New log")?;
        writeln!(w, "2) Show log")?;
        writeln!(w, "3) Edit log")?;
        writeln!(w, "4) Drop log")?;
        writeln!(w, "5) New ref")?;
        writeln!(w, "6) Show ref")?;
        writeln!(w, "7) Edit ref")?;

        if !state.refs.is_empty() {
            writeln!(w, "8) New admin")?;
        }

        if !state.admins.is_empty() {
            writeln!(w, "9) Show admin")?;
            writeln!(w, "10) Drop admin")?;
        }

        if state
            .admins
            .iter()
            .any(|admin| matches!(admin, Some(a) if a.is_admin == 1))
        {
            writeln!(w, "11) Get flag")?;
        }

        writeln!(w, "0) Quit")?;
        write!(w, "> ")?;
        w.flush()?;

        let line = read_line(r)?;
        if line.is_empty() {
            break;
        }

        match line.trim().parse::<u8>().unwrap_or(255) {
            0 => {
                writeln!(w, "Bye.")?;
                break;
            }
            1 => match state.log_new() {
                Ok(index) => writeln!(w, "Created log #{}", index)?,
                Err(e) => writeln!(w, "Error: {}", e)?,
            },
            2 => {
                let index = prompt_index(r, w)?;
                match state.log_show(index) {
                    Ok(data) => hexdump(w, data)?,
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            3 => {
                let index = prompt_index(r, w)?;
                let data = prompt_bytes(r, w)?;
                match state.log_edit(index, &data) {
                    Ok(()) => writeln!(w, "Log #{} updated.", index)?,
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            4 => {
                let index = prompt_index(r, w)?;
                match state.log_drop(index) {
                    Ok(()) => writeln!(w, "Log #{} dropped.", index)?,
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            5 => match state.ref_new() {
                Ok(index) => writeln!(w, "Created ref #{}", index)?,
                Err(e) => writeln!(w, "Error: {}", e)?,
            },
            6 => {
                let index = prompt_index(r, w)?;
                match state.ref_show(index) {
                    Ok(data) => hexdump(w, data)?,
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            7 => {
                let index = prompt_index(r, w)?;
                let data = prompt_bytes(r, w)?;
                match state.ref_edit(index, &data) {
                    Ok(()) => writeln!(w, "Ref #{} updated.", index)?,
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            8 => match state.admin_new() {
                Ok(index) => writeln!(w, "Created admin #{}", index)?,
                Err(e) => writeln!(w, "Error: {}", e)?,
            },
            9 => {
                let index = prompt_index(r, w)?;
                match state.admin_show(index, w) {
                    Ok(()) => {}
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            10 => {
                let index = prompt_index(r, w)?;
                match state.admin_drop(index) {
                    Ok(()) => writeln!(w, "Admin #{} dropped.", index)?,
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            11 => {
                let index = prompt_index(r, w)?;
                match state.admin_flag(index, w) {
                    Ok(()) => {}
                    Err(e) => writeln!(w, "Error: {}", e)?,
                }
            }
            _ => writeln!(w, "Unknown command.")?,
        }
    }
    Ok(())
}
